#!/bin/bash

MONGOD=$(realpath $(dirname $0))/bin/mongod

if grep 'authorization: enabled' mongodb.conf > /dev/null; then
    echo "already initialized"
    exit 1
fi

./start.sh

bin/mongo --port 28018 --eval "
    db.getMongo().getDB('admin').createUser({user:'root', pwd:'$DB_PASS', roles:['root']});
"
kill $(ps ux | grep -w $MONGOD | grep -v grep | awk '{print $2}')
sed -i 's/authorization: disabled/authorization: enabled/' mongodb.conf

sleep 2

./start.sh

