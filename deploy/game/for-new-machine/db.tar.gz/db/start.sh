#!/bin/bash

/data/db/bin/mongod --config /data/db/mongodb.conf
