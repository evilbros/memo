#!/bin/bash

cd $(dirname $0)

tarfile=$1

[ ! $tarfile ] && echo "$0 tarfile" && exit 1

read -p "Are you sure to restore DB $tarfile ? [Yes/No]" x
[ "$x" != "Yes" ] && exit 1

db_user=root
db_pass=$DB_PASS
db_ip=localhost
db_port=28018

dir=${tarfile%.tar.gz}
tar -xf $tarfile
mongorestore --uri mongodb://${db_user}:${db_pass}@${db_ip}:${db_port}/ --drop $dir
rm -rf $dir

