#!/bin/bash

source ~/.bashrc

cd $(dirname $0)

prefix=$1
timestr=$2

[ ! $prefix ]  && prefix="db"
[ ! $timestr ] && timestr=$(date +%Y-%m-%d_%H-%M)

db_user=root
db_pass=$DB_PASS
db_ip=localhost
db_port=28018

out_date_min=4320 # out date minutes

dump_path=./${prefix}_${timestr} # relative path

/data/db/bin/mongodump --uri mongodb://${db_user}:${db_pass}@${db_ip}:${db_port}/ -o $dump_path
rm $dump_path/admin -rf
tar -czf $dump_path.tar.gz $dump_path

rm $dump_path -rf
find . -mmin +$out_date_min -name "db_*" -delete

